---
title: "Teaching Assistant, Intelligent Control Process (WS2017)"
collection: teaching
type: "Master's course"
permalink: /teaching/ta_icp2017
venue: "Technical University of Munich"
date: 2017-09-01
location: "Munich, Germany"
---

Teaching assistant for the Master's course <b>Intelligent Control Process</b>.

* Approx. 100 participants per semester
* Support lectures and provide supervision to students