---
title: "Teaching Assistant, Project Course: Cognitive Robotics and Control (WS2020)"
collection: teaching
type: "Master's course"
permalink: /teaching/ta_project2020
venue: "Technical University of Munich"
date: 2020-09-01
location: "Munich, Germany"
---

Teaching assistant for the Master's course <b>Project Course: Cognitive Robotics and Control</b>.

* Approx. 10 participants per semester
* Lead one robotic research project for a group of students (25 hrs.) 
* Provide supervision to students